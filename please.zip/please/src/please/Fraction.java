package please;

public class Fraction {
	int numerator;
	int denominator;
//	public void input() {
//		Scanner Input = new Scanner(Sytem.in);
//		
//	}
	public Fraction Add(Fraction x) {
		Fraction f = new Fraction();
		f.numerator = this.numerator*x.denominator+this.denominator*x.numerator;
		f.denominator = this.denominator*x.denominator;
		return f;
	}
	public Fraction Subtract(Fraction x) {
		Fraction f = new Fraction();
		f.numerator = this.numerator*x.denominator-this.denominator*x.numerator;
		f.denominator = this.denominator*x.denominator;
		return f;
	}
	public Fraction Multiply(Fraction x) {
		Fraction f = new Fraction();
		f.numerator = this.numerator*x.numerator;
		f.denominator = this.denominator*x.denominator;
		return f;
	}
	public Fraction Divide(Fraction x) {
		Fraction f = new Fraction();
		f.numerator = this.numerator*x.denominator;
		f.denominator = this.denominator*x.numerator;
		return f;
	}
}
