package please;

public class RunFraction {
	public static void main(String[] args) {
		Fraction f1 = new Fraction();
		f1.numerator = 1;
		f1.denominator = 2;
		Fraction f2 = new Fraction();
		f2.numerator = 2;
		f2.denominator = 3;
		Fraction f3 = f1.Add(f2);
		Fraction f4 = f1.Subtract(f2);
		Fraction f5 = f1.Multiply(f2);
		Fraction f6 = f1.Divide(f2);
		System.out.println("ADD: " + f3.numerator + "/" + f3.denominator);
		System.out.println("Subtract: " + f4.numerator + "/" + f4.denominator);
		System.out.println("Multiply: " + f5.numerator + "/" + f5.denominator);
		System.out.println("Divide: " + f6.numerator + "/" + f6.denominator);
//		System.out.println("Print So Thap Phan: " + ((f2.numerator%f2.denominator) * 10));
	}
}
